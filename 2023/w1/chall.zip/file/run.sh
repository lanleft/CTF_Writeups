#!/bin/bash

java -Djava.library.path=. -Dfile.encoding=UTF-8 Main