#!/bin/sh
LD_LIBRARY_PATH=./bin ./bin/chall
