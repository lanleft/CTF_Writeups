#! /bin/bash
cd /home/pwn && ./diagemu
