* Based on git commit hash: 63cb7fb817e60e5633fb622baf18c59da7a0a682
* args.gn:
dcheck_always_on = false                                                                                                                                          
is_debug = false
target_cpu = "x64"
v8_enable_sandbox = true

* It is recommended that you solve this challenge on a Debian Linux 11.5.0 machine.