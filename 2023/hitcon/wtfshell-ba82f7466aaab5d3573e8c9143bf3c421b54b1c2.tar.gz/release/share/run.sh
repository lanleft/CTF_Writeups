#!/bin/sh

exec 2>/dev/null
timeout 86400 env -i /home/user/wtfshell
