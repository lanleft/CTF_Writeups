/* -*-  mode:c; tab-width:8; c-basic-offset:8; indent-tabs-mode:nil;  -*- */
/*
   Copyright (C) 2016 by Ronnie Sahlberg <ronniesahlberg@gmail.com>

Redistribution and use in source and binary forms, with or without modification, are permitted provided that the following conditions are met:

1. Redistributions of source code must retain the above copyright notice, this list of conditions and the following disclaimer.

2. Redistributions in binary form must reproduce the above copyright notice, this list of conditions and the following disclaimer in the documentation and/or other materials provided with the distribution.

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
*/

#define _GNU_SOURCE

#include <inttypes.h>
#include <poll.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>

#include "smb2/smb2.h"
#include "smb2/libsmb2.h"
#include "smb2/libsmb2-raw.h"
#include "../include/libsmb2-private.h"

#define SMB2_LIST_REMOVE(list, item) \
	if ((*list) == (item)) { 				\
	   (*list) = (item)->next;				\
	} else {						\
	   void *head = (*list);				\
	   while ((*list)->next && (*list)->next != (item))     \
	     (*list) = (*list)->next;				\
	   if ((*list)->next != NULL) {		    	    	\
	      (*list)->next = (*list)->next->next;		\
	   }  		      					\
	   (*list) = head;					\
	}

#define SMB2_LIST_ADD(list, item) \
	do {							\
		(item)->next = (*list);				\
		(*list) = (item);				\
	} while (0);


int is_finished;
struct sync_cb_data
{
    int is_finished;
    int status;
    void *ptr;
};
struct smb2_dirent_internal
{
    struct smb2_dirent_internal *next;
    struct smb2dirent dirent;
};

struct smb2dir
{
    struct smb2dir *next;
    smb2_command_cb cb;
    void *cb_data;
    smb2_file_id file_id;

    struct smb2_dirent_internal *entries;
    struct smb2_dirent_internal *current_entry;
    int index;
    int v0;
    int v1;
};
char *path;

struct myStruct {
    int id;
    char buf[0x40];
};

static void od2_cb(struct smb2_context *smb2, int status,
                     void *command_data, void *private_data)
{
    struct sync_cb_data *cb_data = private_data;

    if (cb_data->status == SMB2_STATUS_CANCELLED)
    {
        printf("[-] private_data: %p\n", cb_data);
        free(cb_data);
        return;
    }

    cb_data->is_finished = 1;
    cb_data->ptr = command_data;
}

static void od3_cb(struct smb2_context *smb2, int status,
                     void *command_data, void *private_data)
{
    struct sync_cb_data *cb_data = private_data;

    if (cb_data->status == SMB2_STATUS_CANCELLED)
    {
        printf("[-] private_data: %p\n", cb_data);
        free(cb_data);
        return;
    }

    cb_data->is_finished = 1;
    cb_data->ptr = command_data;
}

static int wait_for_reply2(struct smb2_context *smb2,
                          struct sync_cb_data *cb_data)
{
    time_t t = time(NULL);

    while (!cb_data->is_finished)
    {
        struct pollfd pfd;

        pfd.fd = smb2_get_fd(smb2);
        pfd.events = smb2_which_events(smb2);

        if (poll(&pfd, 1, 1000) < 0)
        {
            smb2_set_error(smb2, "Poll failed");
            return -1;
        }
        if (smb2->timeout)
        {
            smb2_timeout_pdus(smb2);
        }
        if (smb2->fd == -1 && ((time(NULL) - t) > (smb2->timeout)))
        {
            smb2_set_error(smb2, "Timeout expired and no connection exists\n");
            return -1;
        }
        if (pfd.revents == 0)
        {
            continue;
        }
        if (smb2_service(smb2, pfd.revents) < 0)
        {
            smb2_set_error(smb2, "smb2_service failed with : "
                                 "%s\n",
                           smb2_get_error(smb2));
            return -1;
        }
    }

    return 0;
}

static void
od_close_cb(struct smb2_context *smb2, int status,
            void *command_data, void *private_data)
{
    struct smb2dir *dir = private_data;

    if (status != SMB2_STATUS_SUCCESS)
    {
        puts("[-] od_close_cb");
        dir->cb(smb2, -12, NULL, dir->cb_data);
        free_smb2dir(smb2, dir);
        return;
    }

    dir->current_entry = dir->entries;
    dir->index = 0;

    /* dir will be freed in smb2_closedir() */
    dir->cb(smb2, 0, dir, dir->cb_data);
}

void
free_smb2dir(struct smb2_context *smb2, struct smb2dir *dir)
{
    SMB2_LIST_REMOVE(&smb2->dirs, dir);
    while (dir->entries)
    {
        struct smb2_dirent_internal *e = dir->entries->next;

        free(discard_const(dir->entries->dirent.name));
        free(dir->entries);
        dir->entries = e;
    }
    free(dir);
}

int
decode_dirents(struct smb2_context *smb2, struct smb2dir *dir,
               struct smb2_iovec *vec)
{
    struct smb2_dirent_internal *ent;
    struct smb2_fileidfulldirectoryinformation fs;
    uint32_t offset = 0;

    do
    {
        struct smb2_iovec tmp_vec;

        /* Make sure we do not go beyond end of vector */
        if (offset >= vec->len)
        {
            smb2_set_error(smb2, "Malformed query reply.");
            return -1;
        }

        ent = calloc(1, sizeof(struct smb2_dirent_internal));
        if (ent == NULL)
        {
            smb2_set_error(smb2, "Failed to allocate "
                                 "dirent_internal");
            return -1;
        }
        SMB2_LIST_ADD(&dir->entries, ent);

        tmp_vec.buf = &vec->buf[offset];
        tmp_vec.len = vec->len - offset;

        smb2_decode_fileidfulldirectoryinformation(smb2, &fs,
                                                   &tmp_vec);
        /* steal the name */
        ent->dirent.name = fs.name;
        ent->dirent.st.smb2_type = SMB2_TYPE_FILE;
        if (fs.file_attributes & SMB2_FILE_ATTRIBUTE_DIRECTORY)
        {
            ent->dirent.st.smb2_type = SMB2_TYPE_DIRECTORY;
        }
        if (fs.file_attributes & SMB2_FILE_ATTRIBUTE_REPARSE_POINT)
        {
            ent->dirent.st.smb2_type = SMB2_TYPE_LINK;
        }
        ent->dirent.st.smb2_nlink = 0;
        ent->dirent.st.smb2_ino = fs.file_id;
        ent->dirent.st.smb2_size = fs.end_of_file;
        ent->dirent.st.smb2_atime = fs.last_access_time.tv_sec;
        ent->dirent.st.smb2_atime_nsec = fs.last_access_time.tv_usec * 1000;
        ent->dirent.st.smb2_mtime = fs.last_write_time.tv_sec;
        ent->dirent.st.smb2_mtime_nsec = fs.last_write_time.tv_usec * 1000;
        ent->dirent.st.smb2_ctime = fs.change_time.tv_sec;
        ent->dirent.st.smb2_ctime_nsec = fs.change_time.tv_usec * 1000;
        ent->dirent.st.smb2_btime = fs.creation_time.tv_sec;
        ent->dirent.st.smb2_btime_nsec = fs.creation_time.tv_usec * 1000;

        offset += fs.next_entry_offset;
    } while (fs.next_entry_offset);

    return 0;
}

static void
query_cb2(struct smb2_context *smb2, int status,
         void *command_data, void *private_data)
{
    puts("callback query_cb2");
    struct smb2dir *dir = private_data;
    struct smb2_query_directory_reply *rep = command_data;

    if (status == SMB2_STATUS_SUCCESS)
    {
        struct smb2_iovec vec;
        struct smb2_query_directory_request req;
        struct smb2_pdu *pdu;

        vec.buf = rep->output_buffer;
        vec.len = rep->output_buffer_length;

        if (decode_dirents(smb2, dir, &vec) < 0)
        {
            dir->cb(smb2, -12, NULL, dir->cb_data);
            free_smb2dir(smb2, dir);
            return;
        }

        /* We need to get more data */
        memset(&req, 0, sizeof(struct smb2_query_directory_request));
        req.file_information_class = SMB2_FILE_ID_FULL_DIRECTORY_INFORMATION;
        req.flags = 0;
        memcpy(req.file_id, dir->file_id, SMB2_FD_SIZE);
        req.output_buffer_length = 0xffff;
        req.name = "*";

        pdu = smb2_cmd_query_directory_async(smb2, &req, query_cb2, dir);
        if (pdu == NULL)
        {
            dir->cb(smb2, -12, NULL, dir->cb_data);
            free_smb2dir(smb2, dir);
            return;
        }
        smb2_queue_pdu(smb2, pdu);

        return;
    }

    if (status == SMB2_STATUS_NO_MORE_FILES)
    {
        struct smb2_close_request req;
        struct smb2_pdu *pdu;

        /* We have all the data */
        memset(&req, 0, sizeof(struct smb2_close_request));
        req.flags = SMB2_CLOSE_FLAG_POSTQUERY_ATTRIB;
        memcpy(req.file_id, dir->file_id, SMB2_FD_SIZE);

        puts("[-] No more files");
        pdu = smb2_cmd_close_async(smb2, &req, od_close_cb, dir);
        if (pdu == NULL)
        {
            dir->cb(smb2, -12, NULL, dir->cb_data);
            free_smb2dir(smb2, dir);
            return;
        }
        smb2_queue_pdu(smb2, pdu);

        return;
    }
    if (status != SMB2_STATUS_CANCELLED)
    {
        smb2_set_error(smb2, "Query directory failed with (0x%08x) %s. %s",
                    status, nterror_to_str(status),
                    smb2_get_error(smb2));
        dir->cb(smb2, -nterror_to_errno(status), NULL, dir->cb_data);
        // free_smb2dir(smb2, dir);
    }
    return NULL;
}


int smb2_fetchfiles_async(struct smb2_context *smb2, struct smb2dir *dir, void(*callback),
                          struct sync_cb_data *cb_data)
{
    struct smb2_dirent_internal *entries, *next, *entry2, *entry3;
    struct smb2_pdu *pdu;
    struct smb2dir *dirs, *dir2;
    struct smb2_query_directory_request req;
    if (!dir)
    {
        return -1;
    }
    if (dir->v1)
    {
        entries = dir->entries;
        dir->cb = callback;
        dir->cb_data = cb_data;
        if (entries)
        {
            do
            {
                next = entries->next;
                free(entries->dirent.name);
                free(dir->entries);
                dir->entries = next;
                entries = next;
            } while (next);
        }
        memset(&req, 0, sizeof(struct smb2_query_directory_request));
        req.file_information_class = SMB2_FILE_ID_FULL_DIRECTORY_INFORMATION;
        req.flags = SMB2_INDEX_SPECIFIED;
        req.file_index = 0;
        memcpy(req.file_id, dir->file_id, SMB2_FD_SIZE);
        req.output_buffer_length = 8 * 1024;
        req.name = "*";

        pdu = smb2_cmd_query_directory_async(smb2, &req, query_cb2, dir);
        if (pdu)
        {
            smb2_queue_pdu(smb2, pdu);
            return 0;
        }
        else
        {
            smb2_set_error(smb2, "Failed to create query command.");
            dir->cb(smb2, 0xFFFFFFF4, 0LL, dir->cb_data);
            dirs = smb2->dirs;
            if (dir == dirs)
            {
                smb2->dirs = dir->next;
            }
            else
            {
                dir2 = dirs->next;
                if (dirs->next)
                {
                    if (dir == dir2)
                    {
                        dir2 = smb2->dirs;
                    go_next:
                        dir2->next = dir->next;
                    }
                    else
                    {
                        while (1)
                        {
                            smb2->dirs = dir2;
                            if (!dir2->next)
                                break;
                            if (dir == dir2->next)
                                goto go_next;
                            dir2 = dir2->next;
                        }
                    }
                }
                smb2->dirs = dirs;
            }
            entry2 = dir->entries;
            if (entry2)
            {
                do
                {
                    entry3 = entry2->next;
                    free((void *)entry2->dirent.name);
                    free(dir->entries);
                    dir->entries = entry3;
                    entry2 = entry3;
                } while (entry3);
            }
            free(dir);
            return -1;
        }
    }
    return 1;
}

struct smb2dirent *smb2_lazy_readdir(struct smb2_context *smb2, struct smb2dir *dir)
{
    struct smb2dirent *ent = smb2_readdir(smb2, dir);
    int v8, v9, status;
    int result;
    if (ent)
        return ent;
    struct sync_cb_data *cb_data = calloc(1, 0x10);
    if (!cb_data)
    {
        smb2_set_error(smb2, "Failed to allocate sync_cb_data");
        return ent;
    }

    if (smb2_fetchfiles_async(smb2, dir, od3_cb, cb_data) != 0)
    {
        smb2_set_error(smb2, "smb2_fetchfiles_async failed");
        free(cb_data);
        return ent;
    }
    if (wait_for_reply2(smb2, cb_data))
    {
        free(cb_data);
        return ent;
    }
    status = cb_data->status;
    free(cb_data);
    // ///
    if (status) {
        return ent;
    }
    return smb2_readdir(smb2, dir);
}

struct smb2dir *smb2_lazy_opendir(struct smb2_context *smb2, const char *path)
{
    struct sync_cb_data *cb_data;
    void *ptr;

    // puts("opendir function");
    cb_data = calloc(1, sizeof(struct sync_cb_data));
    if (cb_data == NULL)
    {
        smb2_set_error(smb2, "Failed to allocate sync_cb_data");
        return NULL;
    }

    if (smb2_opendir_async(smb2, path,
                           od2_cb, cb_data, 1) != 0)
    {
        smb2_set_error(smb2, "smb2_opendir_async failed");
        free(cb_data);
        return NULL;
    }

    if (wait_for_reply2(smb2, cb_data) < 0) //# -1 
    {
        cb_data->status = SMB2_STATUS_CANCELLED;
        return NULL;
    }

    // printf("hereee\n");
    ptr = cb_data->ptr;
    printf("[+] dir: %p\n", ptr);
    free(cb_data);
    return ptr;
}

int main(int argc, char *argv[])
{
    struct smb2_context *smb2;
    struct smb2_url *url;
    struct pollfd pfd;
    struct smb2dirent *directory;

    smb2 = smb2_init_context();
    if (smb2 == NULL)
    {
        fprintf(stderr, "Failed to init context\n");
        exit(0);
    }

    url = smb2_parse_url(smb2, argv[1]);
    if (url == NULL)
    {
        fprintf(stderr, "Failed to parse url: %s\n",
                smb2_get_error(smb2));
        exit(0);
    }

    // smb2_set_security_mode(smb2, SMB2_NEGOTIATE_SIGNING_ENABLED);

    printf("[+] url->share: %s\n", url->share);
    if (smb2_connect_share(smb2, url->server, url->share, url->user) < 0)
    {
        printf("smb2_connect_share failed. %s\n", smb2_get_error(smb2));
        exit(10);
    }

    puts("[+] opendir...");
    printf("[+] path : %s\n", url->path);
    struct smb2dir *dir = smb2_lazy_opendir(smb2, url->path);
    if (dir == NULL)
    {
        printf("smb2_opendir failed. %s\n", smb2_get_error(smb2));
        exit(10);
    }

    puts("[+] readdir...");
    directory = smb2_lazy_readdir(smb2, dir);

    // smb2_destroy_url(url);
    smb2_closedir(smb2, dir); // free
    
    /*
    /// 
    
    
    */
    
    smb2_disconnect_share(smb2);
    smb2_destroy_context(smb2);

    return 0;
}
