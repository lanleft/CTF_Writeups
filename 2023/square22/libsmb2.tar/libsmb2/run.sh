#!/bin/sh

rm -rf build/
mkdir build
cd build
cmake -DCMAKE_BUILD_TYPE=Debug ..
make -j 12 
cd lib 
gcc ../../examples/smb2-ls-async.c -o smb2_ls -lsmb2
./smb2_ls smb://guest@192.168.86.39:445/evil
